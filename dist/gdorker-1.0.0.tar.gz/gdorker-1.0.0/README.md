# GDORKER

## What is it

CLI tool for searching with DuckDuckgo and Google Search API in friendly format 

## Installation and run
```
pipx install gdorker
gdorker --help
```

## Get API Keys for Google Search API

You can skip this step if you are going to use DDG only.

https://programmablesearchengine.google.com/controlpanel/

place keys here `~/.config/gdorker/config.json`

Config file will be created automatically after initial run

## Caveats

Might be glitchy. Gdorker was created for personal use and was not tested well, niether it has automated tests.
